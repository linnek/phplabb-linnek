
<?php include("header.php"); ?>

	<div id="mainBody">
		<p>
		 Welcome to Reading Club!
		</p>
	</div>


<?php include("footer.php"); ?>