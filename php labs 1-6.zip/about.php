<?php include("header.php"); ?>

<div id="allMembers">
	<div class="member">
		<img src="img/member.png">
		<p>Anna Andersson<br>27 years old<br>Stockholm<br>Favorite book:</p>
	</div>
	<div class="member">
		<img src="img/member.png">
		<p>Stina Jonsson<br>30 years old<br>Jönköping<br>Favorite book:</p>
	</div>
	<div class="member">
		<img src="img/member.png">
		<p>Emma Eriksson<br>19 years old<br>Dalarna<br>Favorite book:</p>
	</div>
</div>

<?php include("footer.php"); ?>

