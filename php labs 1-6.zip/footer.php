
</body>
<footer>
	<div id="foot">
		<img src="img/facebook.png">
		<img src="img/insta.png">
		<img src="img/linkedin.png">
	</div>
</footer>
</html>